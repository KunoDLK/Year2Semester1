﻿using System.ComponentModel.DataAnnotations;

namespace ThAmCo.Events.Models
{
    public class Menu
    {
        public Menu() { }

        public int MenuId { get; set; }

        public string MenuName { get; set; }

    }
}
